﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_WPF_MVVM_LoginPage.Model//defining the namespace for the model
{
    public class LoginModel//defining the public class fot login model
    {
        //validating the models
        public string UserName { get; set; }//property for Username
        public int Password { get; set; }//Property for Passowrd
    }
}
