﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using _05_WPF_MVVM_LoginPage.Model;

namespace _05_WPF_MVVM_LoginPage.ViewModel
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private LoginModel _loginModel = new LoginModel();

        public string UserName
        {
            get { return _loginModel.UserName; }
            set { _loginModel.UserName = value; OnPropertyChanged(nameof(UserName)); }
        }

        public string Password
        {
            get { return _loginModel.Password.ToString(); } // Convert int to string
            set
            {
                if (int.TryParse(value, out int result)) // Validate and convert string to int
                {
                    _loginModel.Password = result;
                    OnPropertyChanged(nameof(Password));
                }
            }
        }

        public ICommand LoginCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public LoginViewModel()
        {
            LoginCommand = new RelayCommand(LoginProcess);
            CancelCommand = new RelayCommand(CancelProcess);
        }

        private void LoginProcess(object parameter)
        {
            // Method to process the login
        }

        private void CancelProcess(object parameter)
        {
            // Method to cancel and clear login details
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;

        public RelayCommand(Action<object> executeAction)
        {
            _execute = executeAction;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true; // Implement your logic for CanExecute
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }
    }
}
