﻿using _05_WPF_MVVM_LoginPage.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _05_WPF_MVVM_LoginPage
{
    public partial class MainWindow : Window
    {
        private LoginViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            _viewModel = new LoginViewModel();
            DataContext = _viewModel;
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            // Validate input fields here
            string username = _viewModel.UserName;
            string password = _viewModel.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            // Perform login procedure
            // Replace this with your actual login logic
            if (username == "admin" && password == "password")
            {
                MessageBox.Show("Login successful!");
                // Navigate to next window or perform other actions
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Close the application
            Application.Current.Shutdown();
        }
    }
}
